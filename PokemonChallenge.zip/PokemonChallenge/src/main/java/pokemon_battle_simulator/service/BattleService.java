package pokemon_battle_simulator.service;

import pokemon_battle_simulator.model.BattleResult;
import pokemon_battle_simulator.model.PokemonCard;
import pokemon_battle_simulator.repository.BattleResultRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Random;

@Service
public class BattleService {

	 @Autowired
	    private BattleResultRepository battleResultRepository;

	    public BattleResult simulateBattle(PokemonCard playerCard, PokemonCard computerCard) {
	        int playerAttack = playerCard.getAttackPoints();
	        int computerAttack = computerCard.getAttackPoints();

	        String winner = playerAttack > computerAttack ? "Player" : "Computer";

	        BattleResult result = new BattleResult();
	        result.setPlayer1CardName(playerCard.getName());
	        result.setPlayer1CardAttack(playerAttack);
	        result.setPlayer2CardName(computerCard.getName());
	        result.setPlayer2CardAttack(computerAttack);
	        result.setWinner(winner);

	        return battleResultRepository.save(result);
	    }
    }
			
