package pokemon_battle_simulator.service;



import pokemon_battle_simulator.model.PokemonCard;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Service
public class PokemonCardService {

    private final WebClient webClient;

    public PokemonCardService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.baseUrl("https://api.pokemontcg.io/v2/cards").build();
    }

    public Mono<PokemonCard[]> getPokemonCards() {
        return this.webClient.get()
                .retrieve()
                .bodyToMono(PokemonCard[].class);
    }
}
