package pokemon_battle_simulator.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PokemonBattleSimulatorApplication {

	  public static void main(String[] args)  {
		SpringApplication.run(PokemonBattleSimulatorApplication.class, args);
	}

}




