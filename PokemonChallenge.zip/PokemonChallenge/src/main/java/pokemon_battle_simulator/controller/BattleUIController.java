package pokemon_battle_simulator.controller;


import pokemon_battle_simulator.model.BattleResult;
import pokemon_battle_simulator.model.PokemonCard;
import pokemon_battle_simulator.service.BattleService;
import pokemon_battle_simulator.service.PokemonCardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.Random;


@Controller
public class BattleUIController {

	 @Autowired
	    private PokemonCardService pokemonCardService;

	    @Autowired
	    private BattleService battleService;

	    @GetMapping("/battle")
	    public String startBattle(Model model) {
	        PokemonCard[] cards = pokemonCardService.getPokemonCards().block();
	        Random rand = new Random();
	        
	        PokemonCard playerCard = cards[rand.nextInt(cards.length)];
	        PokemonCard computerCard = cards[rand.nextInt(cards.length)];

	        BattleResult result = battleService.simulateBattle(playerCard, computerCard);

	        model.addAttribute("playerCard", playerCard);
	        model.addAttribute("computerCard", computerCard);
	        model.addAttribute("result", result);

	        return "battle";
	
	
	
}
}
