package pokemon_battle_simulator.controller;


import pokemon_battle_simulator.model.BattleResult;
import pokemon_battle_simulator.model.PokemonCard;
import pokemon_battle_simulator.service.BattleService;
import pokemon_battle_simulator.service.PokemonCardService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.Random;

import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/battle")
public class BattleController {

	@Autowired
    private PokemonCardService pokemonCardService;

    @Autowired
    private BattleService battleService;

    @PostMapping("/start")
    public Mono<BattleResult> startBattle() {
        return pokemonCardService.getPokemonCards().flatMap(cards -> {
            Random rand = new Random();  
            PokemonCard playerCard = cards[rand.nextInt(cards.length)];
            PokemonCard computerCard = cards[rand.nextInt(cards.length)];

            return Mono.just(battleService.simulateBattle(playerCard, computerCard));
        });
    }
}
