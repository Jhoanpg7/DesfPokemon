package pokemon_battle_simulator.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name = "pokemon_card")
public class PokemonCard {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Serializable id;

    @Column(name = "name")
    private String name;

    @Column(name = "attack_points")
    private int attackPoints;

    // Getters y setters
    public Long getId() { return (Long) id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getAttackPoints() { return attackPoints; }
    public void setAttackPoints(int attackPoints) { this.attackPoints = attackPoints; }
}
