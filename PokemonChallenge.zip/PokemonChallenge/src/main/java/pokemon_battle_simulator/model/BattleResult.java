package pokemon_battle_simulator.model;

import jakarta.persistence.*;

@Entity
@Table(name = "battle_result")
public class BattleResult {

	  @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    @Column(name = "player_card_name")
	    private String playerCardName;

	    @Column(name = "player_card_attack")
	    private int playerCardAttack;

	    @Column(name = "computer_card_name")
	    private String computerCardName;

	    @Column(name = "computer_card_attack")
	    private int computerCardAttack;

	    @Column(name = "winner")
	    private String winner;

	    // Getters y setters
	    public Long getId() { return id; }
	    public void setId(Long id) { this.id = id; }

	    public String getPlayer1CardName() { return getPlayer1CardName(); }
	    public void setPlayer1CardName(String player1CardName) { this.playerCardName = player1CardName; }

	    public int getPlayer1CardAttack() { return getPlayer1CardAttack(); }
	    public void setPlayer1CardAttack(int player1CardAttack) { this.playerCardAttack = player1CardAttack; }

	    public String getPlayer2CardName() { return computerCardName; }
	    public void setPlayer2CardName(String player2CardName) { this.computerCardName = player2CardName; }

	    public int getPlayer2CardAttack() { return computerCardAttack; }
	    public void setPlayer2CardAttack(int player2CardAttack) { this.computerCardAttack = player2CardAttack; }

	    public String getWinner() { return winner; }
	    public void setWinner(String winner) { this.winner = winner; }
}
